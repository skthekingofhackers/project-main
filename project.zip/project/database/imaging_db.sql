-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 06, 2023 at 09:37 PM
-- Server version: 10.11.4-MariaDB-1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imaging_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `appointment_number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `sub_department` varchar(50) NOT NULL,
  `aadhar_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`appointment_number`, `name`, `age`, `gender`, `contact`, `department`, `sub_department`, `aadhar_no`, `date`, `time`) VALUES
(1, 'sunil kumar', 20, 'Male', '9654083988', 'imaging', 'Ultrasound', '498192301362', '2023-08-06', '02:14:00'),
(2, 'sunil kumar', 20, 'Male', '9654083988', 'imaging', 'CT scan', '498192301355', '2023-08-06', '02:21:00'),
(3, 'sunny', 20, 'Male', '9654083988', 'imaging', 'CT scan', '498192301362', '2023-08-07', '02:52:00'),
(4, 'ajnssw', 76, 'Male', '8769875098', 'imaging', 'Ultrasound', '498192301567', '2023-08-07', '02:57:00'),
(5, 'dsks', 20, 'Male', '8864589657', 'imaging', 'Ultrasound', '498192300000', '2023-08-07', '03:01:00'),
(6, 'sqgdo', 66, 'Female', '9053647890', 'imaging', 'CT scan', '489056790765', '2023-08-07', '03:06:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`appointment_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
