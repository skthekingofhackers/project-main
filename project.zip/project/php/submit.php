<?php
// Your database connection details
$servername = "localhost";
$username = "admin";
$password = "admin";
$dbname = "imaging_db";

try {
    // Establishing the database connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handling form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Gather form data
        $name = $_POST["name"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $contact = $_POST["contact"];
        $department = $_POST["department"];
        $sub_department = $_POST["sub_department"];
        $aadhar_no = $_POST["aadhar_no"];
        $appointment_number = $_POST["appointment_number"];
        $date = $_POST["date"];
        $time = $_POST["time"];

        // Prepare the SQL query to insert the data into the database
        $stmt = $conn->prepare("INSERT INTO patients (name, age, gender, contact, department, sub_department, aadhar_no, appointment_number, date, time)
                                VALUES (:name, :age, :gender, :contact, :department, :sub_department, :aadhar_no, :appointment_number, :date, :time)");

        // Bind parameters to the prepared statement
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":age", $age);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":contact", $contact);
        $stmt->bindParam(":department", $department);
        $stmt->bindParam(":sub_department", $sub_department);
        $stmt->bindParam(":aadhar_no", $aadhar_no);
        $stmt->bindParam(":appointment_number", $appointment_number);
        $stmt->bindParam(":date", $date);
        $stmt->bindParam(":time", $time);

        // Execute the prepared statement
        $stmt->execute();

        echo "Registration successful!";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
